Thanks for purchasing The Warrior Game Characters - Pack

Open .scml file using BrashMonkey Spriter!
Download Here: https://brashmonkey.com/download_spriter/

Have have a question?
You can contact me : gimkamu@gmail.com

Don�t forget to rate and share if you like the asset. Thank you.